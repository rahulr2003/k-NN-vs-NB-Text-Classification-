import matplotlib.pyplot as plt

DatasetSize = [15,30,45,60,75,90,105,120,135,150]
Time = [6.419992208480835,
    8.151721954345703,
    9.681407928466797,
    10.286118030548096,
    11.46320390701294,
    12.762939929962158,
    14.383183002471924,
    15.527110815048218,
    17.392688035964966,
    30.157697916030884    
]
plt.xlabel('DatasetSize')
plt.ylabel('Time')
plt.title('Time vs DatasetSize for NB')
plt.plot(DatasetSize,Time)
plt.show()
