import matplotlib.pyplot as plt

DatasetSize = [15,30,45,60,75,90,105,120,135,150]

Accuracy = [97.03389830508475,
85.20749665327979,
82.32189973614776,
81.96078431372548,
84.59143968871595,
83.89247311827957,
82.03713917999632,
80.05135612261273,
81.27958685984794,
77.38980350504514
    ]

plt.xlabel('DatasetSize')
plt.ylabel('Accuracy')
plt.title('Accuracy vs DatasetSize for NB')
plt.plot(DatasetSize,Accuracy)
plt.show()
