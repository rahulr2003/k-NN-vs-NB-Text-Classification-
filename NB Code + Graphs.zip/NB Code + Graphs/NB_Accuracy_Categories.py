import matplotlib.pyplot as plt
def NBAccVSCat():
    x1 = [2,
    4,
    6,
    8,
    10,
    12,
    14,
    16,
    18,
    20]
    y1 = [97.03389830508475,
85.20749665327979,
82.32189973614776,
81.96078431372548,
84.59143968871595,
83.89247311827957,
82.03713917999632,
80.05135612261273,
81.27958685984794,
77.38980350504514]
    plt.scatter(x1, y1, label = "NB")
    plt.plot(x1, y1, label = "NB")
    plt.bar(x1, y1, label = "NB")
    plt.xlabel('Number of Categories')
    plt.ylabel('Accuracy of classification of whole dataset(%)')
    plt.title('Number of Categories vs Accuracy of NB')
    plt.legend()
    plt.show()


NBAccVSCat()

