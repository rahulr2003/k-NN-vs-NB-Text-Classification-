import matplotlib.pyplot as plt
def NBTimeVSCat():
    x1 = [2,
    4,
    6,
    8,
    10,
    12,
    14,
    16,
    18,
    20]
    y1 = [6.419992208480835,
8.151721954345703,
9.681407928466797,
10.286118030548096,
11.46320390701294,
12.762939929962158,
14.383183002471924,
15.527110815048218,
17.392688035964966,
30.157697916030884]
    plt.scatter(x1, y1, label = "NB")
    plt.plot(x1, y1, label = "NB")
    plt.bar(x1, y1, label = "NB")
    plt.xlabel('Number of Categories')
    plt.ylabel('Time for classification of whole dataset(s)')
    plt.title('Number of Categories vs Time for NB')
    plt.legend()
    plt.show()


NBTimeVSCat()

