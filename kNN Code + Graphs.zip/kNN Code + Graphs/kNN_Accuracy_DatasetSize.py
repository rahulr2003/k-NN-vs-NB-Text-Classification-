import matplotlib.pyplot as plt

DatasetSize = [15,30,45,60,75,90,105,120,135,150]

Accuracy = [87.57062146892656,
69.87179487179486,
66.97449428320141,
65.06535947712419,
67.80804150453956,
70.34408602150538,
66.66666666666666,
67.2604718343765,
67.66604504375269,
65.58682952734998]

plt.xlabel('DatasetSize')
plt.ylabel('Accuracy')
plt.title('Accuracy vs DatasetSize for kNN')
plt.plot(DatasetSize,Accuracy)
plt.show()
