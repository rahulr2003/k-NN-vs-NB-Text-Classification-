import matplotlib.pyplot as plt

DatasetSize = [15,30,45,60,75,90,105,120,135,150]

Time = [142.87065315246582,
        205.79250121116638,
        386.2228729724884,
        686.8286809921265,
        588.5777950286865,
        878.6212949752808,
        1006.0287261009216,
        970.183739900589,
        1740.885215997696,
        1327.5149710178375    
    ]

plt.xlabel('DatasetSize')
plt.ylabel('Time')
plt.title('Time vs DatasetSize for kNN')
plt.plot(DatasetSize,Time)
plt.show()
