import matplotlib.pyplot as plt
def kNNAccVSCat():
    x1 = [2,
    4,
    6,
    8,
    10,
    12,
    14,
    16,
    18,
    20]
    y1 = [87.57062146892656,
69.87179487179486,
66.97449428320141,
65.06535947712419,
67.80804150453956,
70.34408602150538,
66.66666666666666,
67.2604718343765,
67.66604504375269,
65.58682952734998]
    plt.scatter(x1, y1, label = "kNN")
    plt.plot(x1, y1, label = "kNN")
    plt.bar(x1, y1, label = "kNN")
    plt.xlabel('Number of Categories')
    plt.ylabel('Accuracy of classification of whole dataset(%)')
    plt.title('Number of Categories vs Accuracy of kNN')
    plt.legend()
    plt.show()


kNNAccVSCat()

