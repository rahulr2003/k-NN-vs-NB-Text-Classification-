import matplotlib.pyplot as plt
def kNNTimeVSCat():
    x1 = [2,
    4,
    6,
    8,
    10,
    12,
    14,
    16,
    18,
    20]
    y1 = [142.87065315246582,
    205.79250121116638,
    386.2228729724884,
    686.8286809921265,
    588.5777950286865,
    878.6212949752808,
    1006.0287261009216,
    970.183739900589,
    1740.885215997696,
    1327.5149710178375]
    plt.scatter(x1, y1, label = "kNN")
    plt.plot(x1, y1, label = "kNN")
    plt.bar(x1, y1, label = "kNN")
    plt.xlabel('Number of Categories')
    plt.ylabel('Time for classification of whole dataset(s)')
    plt.title('Number of Categories vs Time for kNN')
    plt.legend()
    plt.show()


kNNTimeVSCat()

